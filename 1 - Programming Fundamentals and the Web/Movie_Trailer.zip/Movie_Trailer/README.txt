Movie_Trailer

Movie_Trailer project is a python project which displays information about specific movies and their youtube trailers

Installation.
execute "entertainment_center.py" in 2.7.13